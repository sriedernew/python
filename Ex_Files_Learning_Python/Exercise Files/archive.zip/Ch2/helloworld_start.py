#
# Example file for HelloWorld
#
def main():
    print("Hallo Welt")

if __name__ == "__main__":
    main()

